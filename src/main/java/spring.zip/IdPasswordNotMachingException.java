package spring;

public class IdPasswordNotMachingException extends RuntimeException{

}
